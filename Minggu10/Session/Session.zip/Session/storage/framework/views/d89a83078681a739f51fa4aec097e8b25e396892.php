<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center"> Form Validation dengan Laravel </h1>
                <form action="<?php echo e(route('form-proses')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama" class="control-label">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control <?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" placeholder="Nama Lengkap" value="<?php echo e(old('nama')); ?>">
                        <?php if($errors->has('nama')): ?>
                            <span class="text-danger small">
                                <p> <?php echo e($errors->first('nama')); ?></p>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="alamat" class="control-label">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control <?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" placeholder="Alamat" value="<?php echo e(old('alamat')); ?>">
                        <?php if($errors->has('alamat')): ?>
                            <span class="text-danger small">
                                <p> <?php echo e($errors->first('alamat')); ?></p>
                            </span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Enter</button>
                </form>
            </div>
        </div>

    </div>
    
</body>
</html><?php /**PATH D:\KULIAH\Session\Session\resources\views/formulir.blade.php ENDPATH**/ ?>